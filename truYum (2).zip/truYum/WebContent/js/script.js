// Include truYum form validation functions here
var nameValid = 1 , priceValid = 1 , dateOfLaunchValid = 1 , categoryValid = 1;
function nameValidation(){
	var valName = document.getElementById('name').value;
                var regex=/^[_A-z]*((-|\s)*[_A-z])*$/g;
                var isValid = regex.test(valName);
                var msg = "";
                if(valName == "" || valName == null){
                   msg = "Title is required.";
                }
                else if(valName.length < 2 || valName.length > 65){
                    msg="Title should have 2 to 65 characters.";
                }
                else{
                    msg = "";
                    nameValid = 0;
                }
                
                document.getElementById("name-validation").innerHTML=msg;
}
function dateOfLaunch(){
	
}
function validateMenuItemForm(event){
	var valPrice = document.getElementById('price').value;
	var regex = /^[0-9]+([.,][0-9]{1,2})?$/g;
                var isValid = regex.test(valPrice);
                var msg = "";
                if(valPrice == "" || valPrice == null){
                    msg = "Price is required.&emsp;&emsp;&emsp;&ensp;&ensp;";
                }
                else if(isValid == false){
                    msg = "Price has to be a number.";
                }
                else{
                    msg = "";
                    priceValid = 0;
                }
                
                document.getElementById("price-validation").innerHTML=msg;
	var valDateOfLaunch = document.getElementById('dateOfLaunch').value;
	msg = "";
	if(valDateOfLaunch == "" || valDateOfLaunch == null){
	   msg = "Date of Launch is required.";
	}
	else{
		dateOfLaunchValid = 0;
	}
	document.getElementById("date-of-launch-validation").innerHTML=msg;
	var valCategory = document.getElementById('category').value;
	var msg = "";
	if(valCategory == "" || valCategory == null){
	   msg="Select one category";
	}
	else{
		categoryValid = 0;
	}
	document.getElementById("category-validation").innerHTML=msg;
	if(priceValid == 1 || dateOfLaunchValid == 1 || categoryValid == 1){
		event.preventDefault();
	}
	
}
