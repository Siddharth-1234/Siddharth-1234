
public class CartEmptyException {

}
