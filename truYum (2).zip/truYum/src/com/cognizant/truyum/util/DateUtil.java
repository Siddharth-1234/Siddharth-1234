package com.cognizant.truyum.util;

import java.text.SimpleDateFormat;
import java.util.Date;

public class DateUtil {
	public static Date convertToDate(String date)throws Exception {
		 SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		 Date Date1 = (Date)sdf.parse(date);
		return Date1;
	}
}
