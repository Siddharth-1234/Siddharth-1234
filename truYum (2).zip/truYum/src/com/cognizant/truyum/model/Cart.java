
package com.cognizant.truyum.model;
import java.util.ArrayList;
import java.util.List;

public class Cart {
	
	private double total;
	List<MenuItem> menuItems = new  ArrayList<MenuItem>();
	
	public Cart(double total, List<MenuItem> menuitems) {
		super();
		this.total = total;
		this.menuItems = menuitems;
	}
	
	public double getTotal() {
		return total;
	}
	public void setTotal(double total) {
		
		this.total = total;
	}
	public List<MenuItem> getMenuItems() {
		return menuItems;
	}
	public void setMenuItems(List<MenuItem> menuitems) {
		this.menuItems = menuitems;
	}
	
}
