package com.cognizant.truyum.dao;

public class CartEmptyException extends Exception {

	public CartEmptyException() {
		super();
		// TODO Auto-generated constructor stub
		System.out.println("Cart Is Empty");
	}

	
	
}
