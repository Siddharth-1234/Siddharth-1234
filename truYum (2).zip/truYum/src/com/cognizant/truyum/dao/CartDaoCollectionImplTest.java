
package com.cognizant.truyum.dao;

import java.util.List;

import com.cognizant.truyum.model.Cart;
import com.cognizant.truyum.model.MenuItem;

//import com.cognizant.truyum.model.MenuItem;

public class CartDaoCollectionImplTest {
	public static void main(String[] args) {
		testAddCartItem();
		testRemoveCartItem();
	}

	public static void testAddCartItem() {
		CartDao cartDao = new CartDaoCollectionImpl();
		cartDao.addCartItem(1, 1);
		try {
			Cart cartList = cartDao.getAllCartItems(1);
			System.out.println("\nItem added to cart successfully");

			System.out.println("\nCART\n");
			System.out.println(String.format("%-25s%-25s%-25s%-25s%-25s%-25s\n", "Name", "Price", "Active",
					"Date Of Launch", "Category", "Free Delivery"));
			for (MenuItem item : cartList.getMenuItems()) {
				System.out.println(item);
			}

		} catch (CartEmptyException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static void testGetAllCartItems() {
		CartDao cartDao = new CartDaoCollectionImpl();
		try {
			Cart cartList = cartDao.getAllCartItems(1);
			for (MenuItem item : cartList.getMenuItems()) {
				System.out.println(item);
			}

		} catch (CartEmptyException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static void testRemoveCartItem() {
		CartDao cartDao = new CartDaoCollectionImpl();

		cartDao.removeCartItem(1, 1);
		System.out.println("\nItem has been removed Successfully\n");
		try {
			Cart cartList = cartDao.getAllCartItems(1);

			for (MenuItem item : cartList.getMenuItems()) {
				System.out.println(item);
			}

		} catch (CartEmptyException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
