package com.cognizant.truyum.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.cognizant.truyum.model.Cart;
import com.cognizant.truyum.model.MenuItem;
//import com.cognizant.truyum.model.MenuItem;

public class CartDaoCollectionImpl implements CartDao {

	private static HashMap<Long, Cart> userCarts;

	public CartDaoCollectionImpl() {
		super();
		if (userCarts == null) {
			userCarts = new HashMap<Long, Cart>();

		}
	}

	@Override
	public void addCartItem(long userId, long menuItemId) {
		// TODO Auto-generated method stub
		try {
			MenuItemDao menuItemDao = new MenuItemDaoCollectionImpl();
			MenuItem menuItem = menuItemDao.getMenuItem(menuItemId);
			System.out.println("Adding Item to Cart");
			System.out.println(String.format("%-25s%-25s%-25s%-25s%-25s%-25s\n", "Name", "Price", "Active",
					"Date Of Launch", "Category", "Free Delivery"));
			System.out.println(menuItem);
			if (userCarts.containsKey(userId)) {

				List<MenuItem> cartItems = userCarts.get(userId).getMenuItems();
				cartItems.add(menuItem);
				userCarts.get(userId).setMenuItems(cartItems);
			} else {
				List<MenuItem> cartMenu = new ArrayList<MenuItem>();
				cartMenu.add(menuItem);
				Cart newCart = new Cart(0, cartMenu);
				newCart.setTotal(0);
				userCarts.put(userId, newCart);
			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public void removeCartItem(long userId, long menuItemId) {
		// TODO Auto-generated method stub
		List<MenuItem> userItems = new ArrayList<MenuItem>();
		userItems = userCarts.get(userId).getMenuItems();
		for (MenuItem item : userItems) {
			if (item.getId() == menuItemId) {
				userItems.remove(userItems.indexOf(item));
				break;
			}
		}
		userCarts.get(userId).setMenuItems(userItems);

	}

	@Override
    public Cart getAllCartItems(long userId) throws CartEmptyException {
           double total = 0.0;
           Cart cart = null;
           for (Map.Entry map : userCarts.entrySet()) {
                  if (userId == (long) map.getKey()) {
                        cart = (Cart) map.getValue();
                        List<MenuItem> menuItemList = cart.getMenuItems();
                        if (menuItemList.size() == 0) {
                               throw new CartEmptyException();
                        } else {
                               for (MenuItem item : menuItemList) {
                                      total += item.getPrice();
                               }
                               cart.setTotal(total);
                        }
                  }
           }
           return cart;
    }
}