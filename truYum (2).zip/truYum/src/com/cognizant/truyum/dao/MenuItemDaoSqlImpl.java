package com.cognizant.truyum.dao;
import java.util.Properties;
import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import com.cognizant.truyum.model.MenuItem;



public class MenuItemDaoSqlImpl implements MenuItemDao{
	ArrayList<MenuItem> menuItemList=new ArrayList<MenuItem>();
	@Override
	public List<MenuItem> getMenuItemListAdmin() {
		////System.out.println("inside admin");
		// TODO Auto-generated method stub
		
		    Connection con=ConnectionHandler.getConnection();
			
			String query="select `me_id`,`me_name`,`me_price`,`me_active`,`me_date_of_launch`,`me_category`,`me_free_delivery` from menu_item";
			 try {
				 ////System.out.println("inside try");
				PreparedStatement ps=con.prepareStatement(query);
				////System.out.println("after ps");
				ResultSet rs=ps.executeQuery();
				while(rs.next()) {
					////System.out.println("inside while");
					long menuId=rs.getLong(1);
					String name=rs.getString(2);
					float price=rs.getFloat(3);
					String active=rs.getString(4);
					boolean activeStatus=false;
					if(active.equalsIgnoreCase("Yes")) {
						activeStatus=true;
					}
				  Date date=rs.getDate(5);
				  String category=rs.getString(6);
				  String free=rs.getString(7);
				  boolean freeDelivery=false;
				  if(free.equalsIgnoreCase("Yes")) {
					  freeDelivery=true;
				  }
				  ////System.out.println(menuId+" "+name+" "+price+" "+activeStatus+" "+category+" "+free);
				  menuItemList.add(new MenuItem(menuId,name,price,activeStatus,date,category,freeDelivery));
				 
				}
				return menuItemList;
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				////System.out.println("inside catch");
			}
			 
			
			
			 finally{
                 try {
					con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
          }
			return menuItemList;

			
		}

	@Override
	public List<MenuItem> getMenuItemListCustomer() {
		// TODO Auto-generated method stub
		
		 Connection con=ConnectionHandler.getConnection();
			
			String query="select `me_id`,`me_name`,`me_price`,`me_active`,`me_date_of_launch`,`me_category`,`me_free_delivery` from menu_item where me_active=\"Yes\" and me_date_of_launch <= CURDATE();";
			 try {
				PreparedStatement ps=con.prepareStatement(query);
				ResultSet rs=ps.executeQuery();
				while(rs.next()) {
					long menuId=rs.getLong(1);
					String name=rs.getString(2);
					float price=rs.getFloat(3);
					String active=rs.getString(4);
					boolean activeStatus=false;
					if(active.equalsIgnoreCase("Yes")) {
						activeStatus=true;
					}
				  Date date=rs.getDate(5);
				  String category=rs.getString(6);
				  String free=rs.getString(7);
				  boolean freeDelivery=false;
				  if(free.equalsIgnoreCase("Yes")) {
					  freeDelivery=true;
				  }
				  menuItemList.add(new MenuItem(menuId,name,price,activeStatus,date,category,freeDelivery));
				  
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			 finally{
                 try {
					con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
          }

			
			return menuItemList;
	}

	@Override
	public void modifyMenuItem(MenuItem menuItem)  {
		// TODO Auto-generated method stub
	     
	              Connection con=null;
	              try{
	            	  con=ConnectionHandler.getConnection();
	              String name=menuItem.getName();
	              float price=menuItem.getPrice();
	              String active=null;
	              if(menuItem.isActive())
	                     active="Yes";
	              else
	                     active="No";
	              String category=menuItem.getCategory();
	              String free=null;
	              if(menuItem.isFreeDelivery())
	                     free="Yes";
	              else
	                     free="No";
	////System.out.println("active"+active);
	              int id=(int)menuItem.getId();
	              PreparedStatement pstmt=con.prepareStatement("UPDATE `truyum`.`menu_item` SET me_name=?,me_price=?,me_active=?,me_date_of_launch=?,me_category=?,me_free_delivery=? WHERE me_id=?");
	       pstmt.setString(1, name);
	       pstmt.setFloat(2, price);
	       pstmt.setString(3, active);
	       pstmt.setDate(4, new java.sql.Date(menuItem.getDateOfLaunch().getTime()));
	       pstmt.setString(5, category);
	pstmt.setString(6, free);
	       pstmt.setInt(7, id);
	       pstmt.executeUpdate();
	              }
	              catch(Exception e) {
	            	  
	              }
	              finally{
	                     try {
							con.close();
						} catch (SQLException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
	              }

	}

	@Override
	public MenuItem getMenuItem(long menuItemId) {
		// TODO Auto-generated method stub
		 Connection con=ConnectionHandler.getConnection();
		 //System.out.println("inside getMenuItem");
			
			MenuItem menu=null;
			String query="select `me_id`,`me_name`,`me_price`,`me_active`,`me_date_of_launch`,`me_category`,`me_free_delivery` from menu_item where me_id=?;";
			 try {
				PreparedStatement ps=con.prepareStatement(query);
				//System.out.println("after ps");
				ps.setLong(1, menuItemId);
				ResultSet rs=ps.executeQuery();
				//System.out.println("after rs");
				while(rs.next()) {
					long menuId=(long)(rs.getInt(1));
					//System.out.println("menuId in getmenu "+menuId);
					String name=rs.getString(2);
					float price=rs.getFloat(3);
					String active=rs.getString(4);
					boolean activeStatus=false;
					if(active.equalsIgnoreCase("Yes")) {
						activeStatus=true;
					}
				  Date date=rs.getDate(5);
				  String category=rs.getString(6);
				  String free=rs.getString(7);
				  boolean freeDelivery=false;
				  if(free.equalsIgnoreCase("Yes")) {
					  freeDelivery=true;
				  }
				
				   
				  menu=new MenuItem(menuId,name,price,activeStatus,date,category,freeDelivery);
				  //System.out.println("inside getMneuItem");
				  //System.out.println(menu);
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			 finally{
                 try {
					con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
          }

			return menu;
			 
			
	
	}

}
