package com.cognizant.truyum.dao;

import java.util.ArrayList;
import java.util.List;

import com.cognizant.truyum.model.MenuItem;
import com.cognizant.truyum.util.DateUtil;

public class MenuItemDaoCollectionImplTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		testGetMenuItemListAdmin();
		testGetMenuItemListCustomer();
		testModifyMenuItem();
	}

	public static void testGetMenuItemListAdmin() {
		MenuItemDao menuItemDao;
		try {
			menuItemDao = new MenuItemDaoCollectionImpl();
			List<MenuItem> menuItems = new ArrayList<MenuItem>();
			menuItems = menuItemDao.getMenuItemListAdmin();
			System.out.println("\n\nMenu Item List Admin\n\n");
			System.out.println(String.format("%-25s%-25s%-25s%-25s%-25s%-25s\n", "Name", "Price", "Active",
					"Date Of Launch", "Category", "Free Delivery"));
			for (MenuItem items : menuItems) {
				System.out.println(items);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public static void testGetMenuItemListCustomer() {

		MenuItemDao menuItemDao;
		try {
			menuItemDao = new MenuItemDaoCollectionImpl();
			List<MenuItem> menuItems = new ArrayList<MenuItem>();
			menuItems = menuItemDao.getMenuItemListCustomer();
			System.out.println("\n\nMenu Item List Customer\n\n");
			System.out.println(String.format("%-25s%-25s%-25s%-25s%-25s%-25s\n", "Name", "Price", "Active",
					"Date Of Launch", "Category", "Free Delivery"));
			for (MenuItem items : menuItems) {
				System.out.println(items);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public static void testModifyMenuItem() {

		try {
			MenuItem item = new MenuItem((long) 1, "Sandwitch", (float) 100.0, true,
					DateUtil.convertToDate("15/03/2017"), "Main Course", true);
			MenuItemDao menuItemDao = new MenuItemDaoCollectionImpl();
			menuItemDao.modifyMenuItem(item);
			System.out.println("\nItem Has been modified Successfully");
			List<MenuItem> menuItems = new ArrayList<MenuItem>();
			menuItems = menuItemDao.getMenuItemListAdmin();
			System.out.println("\n\nMenu Item List Admin\n\n");
			System.out.println(String.format("%-25s%-25s%-25s%-25s%-25s%-25s\n", "Name", "Price", "Active",
					"Date Of Launch", "Category", "Free Delivery"));
			for (MenuItem items : menuItems) {
				System.out.println(items);
			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static void testGetMenuItem() {

	}

}
