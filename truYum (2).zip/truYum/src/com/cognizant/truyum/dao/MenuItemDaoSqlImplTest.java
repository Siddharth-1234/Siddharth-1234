package com.cognizant.truyum.dao;

public class MenuItemDaoSqlImplTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

	public static void testGetMenuItemListAdmin() {

	}

	public static void testGetMenuItemListCustomer() {

	}

	public static void testModifymenuItem() {

	}

	public static void testGetmenuItem() {

	}

}
