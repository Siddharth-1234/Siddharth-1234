package com.cognizant.truyum.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;

import com.cognizant.truyum.model.Cart;
import com.cognizant.truyum.model.MenuItem;


public class CartDaoSqlImpl implements CartDao{

	@Override
	public void addCartItem(long userId, long menuItemId) {
		// TODO Auto-generated method stub
		Connection con= ConnectionHandler.getConnection();
		String query="INSERT INTO `truyum`.`cart` (`ct_us_id`, `ct_pr_id`) VALUES (?,?);";
		try {
			PreparedStatement ps=con.prepareStatement(query);
			ps.setLong(1,userId);
			ps.setLong(2, menuItemId);
			ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 finally{
             try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
      }
		
	}

	@Override
	public Cart getAllCartItems(long userId) throws CartEmptyException {
		// TODO Auto-generated method stub
		Connection con= ConnectionHandler.getConnection();
		ArrayList<MenuItem>menuItemList =new ArrayList<MenuItem>();
		Cart cart=new Cart(0.0,menuItemList);
		
		String query1=" select menu.`me_id`,menu.`me_name`,menu.`me_price`,menu.`me_active`,menu.`me_date_of_launch`,menu.`me_category`,menu.`me_free_delivery` from menu_item  menu inner join cart  cart on menu.me_id=cart.ct_pr_id where  cart.ct_us_id in(select us_id from user where us_id=?);";
		String query2="select cart.ct_us_id ,sum(menu.`me_price`) as TOTAL_PRICE from menu_item  menu inner join cart  cart on menu.me_id= cart.ct_pr_id where cart.ct_us_id in(select user.us_id from user where user.us_id=?); ";
		try {
			PreparedStatement ps=con.prepareStatement(query1);
			ps.setLong(1, userId);
			ResultSet rs=ps.executeQuery();
			while(rs.next()) {
				long menuId=rs.getLong(1);
				String name=rs.getString(2);
				float price=rs.getFloat(3);
				String active=rs.getString(4);
				boolean activeStatus=false;
				if(active.equalsIgnoreCase("Yes")) {
					activeStatus=true;
				}
			  Date date=rs.getDate(5);
			  String category=rs.getString(6);
			  String free=rs.getString(7);
			  boolean freeDelivery=false;
			  if(free.equalsIgnoreCase("Yes")) {
				  freeDelivery=true;
			  }
			  ////System.out.println(menuId+" "+name+" "+price+" "+activeStatus+" "+category+" "+free);
			  menuItemList.add(new MenuItem(menuId,name,price,activeStatus,date,category,freeDelivery));
			}
			if(menuItemList.size()==0) {
				throw new CartEmptyException();
			}
			PreparedStatement ps1=con.prepareStatement(query2);
			ps1.setLong(1, userId);
			ResultSet rs1=ps1.executeQuery();
			while(rs1.next()) {
				double total=rs1.getDouble(2);
				cart.setTotal(total);
			}
			cart.setMenuItems(menuItemList);
			return cart;
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 finally{
             try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
      }
		return cart;
	}

	@Override
	public void removeCartItem(long userId, long menuItemId) {
		// TODO Auto-generated method stub
		Connection con= ConnectionHandler.getConnection();
		String query="delete from cart where ct_pr_id=? and ct_us_id=?;";
		PreparedStatement ps;
		try {
			ps = con.prepareStatement(query);
			ps.setLong(1, menuItemId);
			ps.setLong(2,userId);
			ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally{
            try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
     }
		
	}

}
