package com.cognizant.truyum.dao;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Date;

import com.cognizant.truyum.model.MenuItem;
import com.cognizant.truyum.util.DateUtil;

public class MenuItemDaoCollectionImpl implements MenuItemDao {

	private static List<MenuItem> menuItemList;

	public MenuItemDaoCollectionImpl() throws Exception {
		super();
		// TODO Auto-generated constructor stub

		if (menuItemList == null) {
			menuItemList = new ArrayList<MenuItem>();
			menuItemList.add(new MenuItem((long) 1, "Sandwitch", (float) 99.0, true,
					DateUtil.convertToDate("15/03/2017"), "Main Course", true));
			menuItemList.add(new MenuItem((long) 2, "Burger", (float) 129.0, true, DateUtil.convertToDate("23/12/2017"),
					"Main Course", false));
			menuItemList.add(new MenuItem((long) 3, "Pizza", (float) 149.0, true, DateUtil.convertToDate("21/08/2018"),
					"Main Course", false));
			menuItemList.add(new MenuItem((long) 4, "French Fries", (float) 57.0, false,
					DateUtil.convertToDate("02/07/2017"), "Starters", true));
			menuItemList.add(new MenuItem((long) 5, "Chocolate Brownie", (float) 32.0, true,
					DateUtil.convertToDate("02/11/2022"), "Dessert", true));

		}
	}

	@Override
	public List<MenuItem> getMenuItemListAdmin() {
		// TODO Auto-generated method stub
		return menuItemList;
	}

	@Override
	public List<MenuItem> getMenuItemListCustomer() {
		// TODO Auto-generated method stub
		List<MenuItem> menuItemListCustomer = new ArrayList<MenuItem>();
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		Date date = new Date();
		String today = sdf.format(date);
		try {
			Date Today = DateUtil.convertToDate(today);
			for (MenuItem Items : menuItemList) {
				if (Today.compareTo(Items.getDateOfLaunch()) < 0 && Items.isActive() == true) {
					menuItemListCustomer.add(Items);
				}
			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return menuItemListCustomer;
	}

	@Override
	public void modifyMenuItem(MenuItem menuitem) {
		// TODO Auto-generated method stub
		for (MenuItem item : menuItemList) {
			if (item.equals(menuitem)) {
				item.setActive(menuitem.isActive());
				item.setCategory(menuitem.getCategory());
				item.setDateOfLaunch(menuitem.getDateOfLaunch());
				item.setFreeDelivery(menuitem.isFreeDelivery());
				item.setName(menuitem.getName());
				item.setPrice(menuitem.getPrice());
			}
		}

	}

	@Override
	public MenuItem getMenuItem(long menuItemId) {
		// TODO Auto-generated method stub
		for (MenuItem item : menuItemList) {
			if (item.getId() == menuItemId) {
				return item;
			}
		}
		return null;
	}
}
